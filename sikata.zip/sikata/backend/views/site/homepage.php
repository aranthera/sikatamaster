<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\base\Model;

?>

<h1>Selamat datang, <?php ?></h1>
<h2>Pengumuman :</h2>
<p>Sabtu libur</p>