<?php
/* @var $this yii\web\View */

use yii\helpers\Html;

?>

<h2>Absensi [nama] <?php ?></h2>

<form action="action_page.php">
  Tanggal:
  <input type="date" name="bday">
<!--  <input type="submit"> -->

</form>

